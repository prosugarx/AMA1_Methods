﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMA1_metod.Interfaces
{
    public interface IOzellik2
    {
        void dinle(string isim);

        void yaz(string isim);
    }


}
