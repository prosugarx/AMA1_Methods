﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMA1_metod.Composition
{
    public class Kulak
    {
        public string şekil;

        public Kulak(string şekil) 
        {
            this.şekil=şekil;
        }
    }
}
