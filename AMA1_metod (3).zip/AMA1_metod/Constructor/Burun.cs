﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMA1_metod.Composition
{
    public class Burun
    {
        public string tip;

        
        public Burun(string tip)
        {
            this.tip = tip;
        }
    }
}
