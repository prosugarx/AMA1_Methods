﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMA1_metod.Classes
{
    public class YeniArrayList : ArrayList
    {
        public void arayaEkle(object o)
        {
            Console.WriteLine("ilgili obje :" + o + "araya eklenmiştir");
        }
    }
}



