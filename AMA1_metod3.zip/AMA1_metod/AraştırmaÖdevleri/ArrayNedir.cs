﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMA1_metod.ArrayAraştırma
{
    public class ArrayNedir
    {
        /*
        aynı türdeki verileri depolamak için kullanılır
        ilk eleman 0 indeksindedir
        dizi oluşturulduktan sonra boyutu değiştirilemez
        Sıralı bir yapıya sahiptirler ve elemanlarına indeks numaraları kullanılarak erişilebilir
         
         
         */
    }
}
