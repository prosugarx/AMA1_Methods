﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMA1_metod.Interfaces
{
    public interface IOzellik3
    {
        void hızlıyım();
        void yüzebilirim();
        void uçabilerem(); 
    }
}
