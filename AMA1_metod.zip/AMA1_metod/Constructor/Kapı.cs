﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMA1_metod.Constructor
{
    public class Kapı
    {
        public int KapıSayısı;

        public Kapı(int kapıSayısı)
        {
            this.KapıSayısı = KapıSayısı;
        }
    }
}
